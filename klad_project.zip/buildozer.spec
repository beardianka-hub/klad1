[app]

# (str) Title of your application
title = Клад

# (str) Package name
package.name = klad

# (str) Package domain (needed for android/ios packaging)
package.domain = org.retro.klad

# (str) Source code where the main.py live
source.dir = .

# (list) Source files to include (let empty to include all the files)
source.include_exts = py,png,wav

# (list) List of inclusions using pattern matching
source.include_patterns = assets/*,icon.png

# (str) Application versioning (method 1)
version = 1.0

# (list) Application requirements
# comma separated e.g. requirements = sqlite3,kivy
requirements = python3,kivy

# (str) Supported orientation (one of landscape, sensorLandscape, portrait or all)
orientation = landscape

# (bool) Indicate if the application should be fullscreen or not
fullscreen = 1

# (list) Permissions
android.permissions = VIBRATE

# (int) Target Android API, should be as high as possible.
android.api = 33

# (int) Minimum API your APK / AAB will support.
android.minapi = 21

# (int) Android NDK API to use. This is the minimum API your app will support, it should usually match android.minapi.
android.ndk_api = 21

# (str) The Android arch to build for, choices: armeabi-v7a, arm64-v8a, x86_64
# You can build for several archs at once by repeating the option.
android.archs = arm64-v8a, armeabi-v7a

# (str) The format used to package the app for release mode (aab or apk or aar).
android.release_artifact = apk

# (str) Path to a custom kivy `config.ini` — leave empty
#p4a.bootstrap = sdl2

# (str) Application icon
icon.filename = icon.png

[buildozer]

# (int) Log level (0 = error only, 1 = info, 2 = debug (with command output))
log_level = 2

# (int) Display warning if buildozer is run as root (0 = False, 1 = True)
warn_on_root = 1
