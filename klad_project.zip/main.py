# -*- coding: utf-8 -*-
"""
КЛАД — аркада в стиле 8-битной приставки (Dendy/NES), в духе Boulder Dash.

Копайте землю, собирайте самоцветы, уворачивайтесь от падающих валунов
и недружелюбных жуков. Как только наберёте нужное число самоцветов —
откроется выход. Управление: стрелки / WASD или экранный крестовину.

Сборка под Android — buildozer (см. README.md).
"""
import os
import random

import kivy
kivy.require('2.1.0')

from kivy.app import App
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle, PushMatrix, PopMatrix, Translate, Rotate
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.widget import Widget

# ---------------------------------------------------------------------------
# Константы
# ---------------------------------------------------------------------------
TILE_W = 20          # ширина поля в клетках
TILE_H = 14          # высота поля в клетках
STEP_TIME = 0.11     # скорость игры (сек на шаг)

# Палитра в духе NES (0..1)
C_BG      = (0.05, 0.05, 0.12)
C_EARTH   = (0.52, 0.30, 0.13)
C_EARTH_D = (0.36, 0.20, 0.08)
C_WALL    = (0.32, 0.32, 0.55)
C_WALL_D  = (0.20, 0.20, 0.38)
C_ROCK    = (0.62, 0.62, 0.68)
C_ROCK_D  = (0.38, 0.38, 0.45)
C_GEM     = (0.15, 0.95, 0.95)
C_GEM_D   = (0.05, 0.55, 0.65)
C_PLAYER  = (1.00, 0.85, 0.20)
C_ENEMY   = (0.95, 0.25, 0.45)
C_DOOR    = (0.45, 0.28, 0.10)
C_DOOR_OK = (1.00, 0.80, 0.10)

# ---------------------------------------------------------------------------
# Уровни
# ---------------------------------------------------------------------------
LEVELS = [
    {
        "quota": 6,
        "time": 150,
        "map": [
            "####################",
            "#P....R....R....G..#",
            "#..G..R..G.R.......#",
            "#.....R....R...R...#",
            "#..R..RRR.RRRR.R.G.#",
            "#..R.....E.....R...#",
            "#..RRRRRRRRRRR.RR..#",
            "#G.............R..X#",
            "#.RRRRRRRR.RRRRR...#",
            "#......G...R.....G.#",
            "#.RRRRRRRR.RRRRR...#",
            "#....G..........G..#",
            "####################",
        ],
    },
    {
        "quota": 8,
        "time": 170,
        "map": [
            "####################",
            "#P..R....E....R...G#",
            "#.G.RRRRRRRRR.R.RR.#",
            "#...R.......R.R....#",
            "#RR.R..G..G.R.R.RG.#",
            "#...R.......R.R.R..#",
            "#.G.RRRRRRRRR.R.RR.#",
            "#...R....E....R....#",
            "#.R.RRRRRRRRR.RRRR.#",
            "#.R.....G.....R..X.#",
            "#.RRRRRRRRRRRRRR.R.#",
            "#.....G....G......G#",
            "####################",
        ],
    },
    {
        "quota": 10,
        "time": 200,
        "map": [
            "####################",
            "#P...R....R....R..G#",
            "#.RR.RRRR.RRRR.RR..#",
            "#.G..R..E.R..R..R.G#",
            "#.RR.RRRR.R..RR.R..#",
            "#....R....R...R.RR.#",
            "#RRR.R.GG.R.R.R....#",
            "#....R....R.R.RRRR.#",
            "#.GRRRRRR.R.R....R.#",
            "#.......R...RRRR.R.#",
            "#.RRRRR.RRRR..E..R.#",
            "#G....G....G..G..X.#",
            "####################",
        ],
    },
]

# ---------------------------------------------------------------------------
# Звуки (генерируются заранее, лежат в assets/)
# ---------------------------------------------------------------------------
SOUNDS = {}

def load_sounds():
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
    for name in ("dig", "gem", "die", "win", "step", "rock"):
        path = os.path.join(base, name + ".wav")
        if os.path.exists(path):
            try:
                SOUNDS[name] = SoundLoader.load(path)
            except Exception:
                pass

def play(name):
    snd = SOUNDS.get(name)
    if snd is not None:
        try:
            snd.play()
        except Exception:
            pass

# ---------------------------------------------------------------------------
# Логика игры
# ---------------------------------------------------------------------------
DIRS = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}


class Game:
    def __init__(self):
        self.level_idx = 0
        self.score = 0
        self.lives = 3
        self.pressed = []      # очередь нажатых направлений
        self.tick = 0
        self.over = False      # игра окончена (проигрыш)
        self.won = False       # пройдены все уровни
        self.msg = ""          # сообщение для оверлея
        self.load_level()

    # -- уровни -------------------------------------------------------------
    def load_level(self):
        lvl = LEVELS[self.level_idx]
        self.quota = lvl["quota"]
        self.time_left = float(lvl["time"])
        self.got = 0
        self.dead = False
        self.exit_open = False
        rows = lvl["map"]
        self.grid = []
        for y in range(TILE_H):
            row = rows[y] if y < len(rows) else ""
            row = row.ljust(TILE_W)[:TILE_W]
            self.grid.append(list(row))
        # гарантированно закрываем края стенами
        for x in range(TILE_W):
            self.grid[0][x] = "#"
            self.grid[TILE_H - 1][x] = "#"
        for y in range(TILE_H):
            self.grid[y][0] = "#"
            self.grid[y][TILE_W - 1] = "#"
        # ищем игрока
        self.px = self.py = 1
        for y in range(TILE_H):
            for x in range(TILE_W):
                if self.grid[y][x] == "P":
                    self.px, self.py = x, y
                    self.grid[y][x] = " "
        self.tick = 0
        play("step")

    # -- ввод ---------------------------------------------------------------
    def set_dir(self, d):
        if d in self.pressed:
            self.pressed.remove(d)
        self.pressed.append(d)

    def clear_dir(self, d):
        if d in self.pressed:
            self.pressed.remove(d)

    @property
    def cur_dir(self):
        return DIRS.get(self.pressed[-1]) if self.pressed else None

    # -- основной шаг -------------------------------------------------------
    def step(self, dt):
        if self.over or self.won or self.dead:
            return
        self.time_left -= dt
        if self.time_left <= 0:
            self.kill()
            return
        self.move_player()
        if self.dead:
            return
        self.apply_gravity()
        if self.dead:
            return
        if self.tick % 2 == 0:
            self.move_enemies()
        self.tick += 1

    def move_player(self):
        d = self.cur_dir
        if not d:
            return
        dx, dy = d
        nx, ny = self.px + dx, self.py + dy
        if not (0 <= nx < TILE_W and 0 <= ny < TILE_H):
            return
        cell = self.grid[ny][nx]
        if cell == "#" or cell == "R" or cell == "E":
            return
        if cell == "X":
            if self.exit_open:
                self.finish_level()
            else:
                play("step")
            return
        if cell == ".":
            play("dig")
        if cell == "G":
            self.got += 1
            self.score += 100
            play("gem")
            if self.got >= self.quota:
                self.exit_open = True
                self.score += 250
                play("win")
        self.grid[ny][nx] = " "
        self.px, self.py = nx, ny

    def apply_gravity(self):
        g = self.grid
        for y in range(TILE_H - 2, 0, -1):
            for x in range(1, TILE_W - 1):
                ch = g[y][x]
                if ch not in ("R", "G"):
                    continue
                below = g[y + 1][x]
                if below == " ":
                    # падает вниз
                    if ch == "R" and (x, y + 1) == (self.px, self.py):
                        self.kill()
                        return
                    g[y + 1][x] = ch
                    g[y][x] = " "
                elif below == "E" and ch == "R":
                    # валун раздавил жука -> самоцветы
                    g[y + 1][x] = "R"
                    g[y][x] = "G"
                    self.score += 150
                    play("rock")
                elif below in ("#", "R", "G"):
                    # попытка скатиться вбок
                    moved = False
                    for dx in (-1, 1):
                        sx, sy = x + dx, y + 1
                        if g[y][x + dx] == " " and g[sy][sx] == " ":
                            if (x + dx, y) == (self.px, self.py):
                                continue
                            g[y][x + dx] = ch
                            g[y][x] = " "
                            moved = True
                            break
                    _ = moved

    def move_enemies(self):
        g = self.grid
        positions = [(x, y) for y in range(TILE_H) for x in range(TILE_W)
                     if g[y][x] == "E"]
        for x, y in positions:
            if g[y][x] != "E":
                continue  # его уже снесли
            if random.random() < 0.25:
                continue  # иногда стоит на месте
            dx, dy = random.choice(list(DIRS.values()))
            nx, ny = x + dx, y + dy
            if not (1 <= nx < TILE_W - 1 and 1 <= ny < TILE_H - 1):
                continue
            target = g[ny][nx]
            if target not in (" ", ".", "X", "G"):
                continue
            if (nx, ny) == (self.px, self.py):
                self.kill()
                return
            g[ny][nx] = "E"
            g[y][x] = " "

    # -- события ------------------------------------------------------------
    def kill(self):
        if self.dead:
            return
        self.dead = True
        self.lives -= 1
        play("die")
        if self.lives > 0:
            Clock.schedule_once(lambda dt: self.respawn(), 1.1)
        else:
            self.over = True
            self.msg = "ИГРА ОКОНЧЕНА\n\nСЧЁТ: %d\n\nКоснитесь, чтобы начать заново" % self.score

    def respawn(self):
        if not self.over:
            self.load_level()

    def finish_level(self):
        self.score += int(self.time_left) * 10
        play("win")
        if self.level_idx >= len(LEVELS) - 1:
            self.won = True
            self.msg = "ПОБЕДА!\n\nВЫ НАШЛИ ВЕСЬ КЛАД!\n\nСЧЁТ: %d\n\nКоснитесь, чтобы играть снова" % self.score
        else:
            self.level_idx += 1
            Clock.schedule_once(lambda dt: self.load_level(), 0.6)

    def restart(self):
        self.__init__()

# ---------------------------------------------------------------------------
# Отрисовка
# ---------------------------------------------------------------------------
class GameWidget(Widget):
    def __init__(self, game, hud, overlay, **kw):
        super().__init__(**kw)
        self.game = game
        self.hud = hud
        self.overlay = overlay
        self.tile = 16
        self.ox = self.oy = 0
        self.bind(pos=self.redraw, size=self.redraw)
        Clock.schedule_interval(self.tick, STEP_TIME)
        Clock.schedule_interval(self.update_hud, 0.1)

    def tick(self, dt):
        self.game.step(dt)
        self.redraw()
        self.update_hud()
        if self.game.over or self.game.won:
            self.overlay.text = self.game.msg
        else:
            self.overlay.text = ""

    def update_hud(self, dt=None):
        g = self.game
        self.hud.text = (
            "[b]УРОВЕНЬ[/b] %d/%d   [b]СЧЁТ[/b] %d   [b]КЛАД[/b] %d/%d   "
            "[b]ВРЕМЯ[/b] %d   [b]ЖИЗНИ[/b] %d"
            % (g.level_idx + 1, len(LEVELS), g.score, g.got, g.quota,
               max(0, int(g.time_left)), max(0, g.lives))
        )

    def on_touch_down(self, touch):
        if self.game.over or self.game.won:
            self.game.restart()
            return True
        return super().on_touch_down(touch)

    # -- рисование ----------------------------------------------------------
    def redraw(self, *args):
        g = self.game
        self.canvas.clear()
        ts = min(self.width / TILE_W, self.height / TILE_H)
        self.tile = ts
        self.ox = (self.width - ts * TILE_W) / 2.0
        self.oy = (self.height - ts * TILE_H) / 2.0

        def cell_xy(x, y):
            return (self.ox + x * ts, self.oy + (TILE_H - 1 - y) * ts)

        with self.canvas:
            Color(*C_BG)
            Rectangle(pos=self.pos, size=self.size)
            for y in range(TILE_H):
                for x in range(TILE_W):
                    ch = g.grid[y][x]
                    cx, cy = cell_xy(x, y)
                    self.draw_tile(ch, cx, cy, ts)
            # игрок
            cx, cy = cell_xy(g.px, g.py)
            if not g.dead or int(g.time_left * 10) % 2 == 0:
                self.draw_player(cx, cy, ts)
            # вспышка при смерти
            if g.dead:
                Color(0.9, 0.1, 0.1, 0.35)
                Rectangle(pos=self.pos, size=self.size)

    def draw_tile(self, ch, cx, cy, ts):
        if ch == "#":
            Color(*C_WALL)
            Rectangle(pos=(cx, cy), size=(ts, ts))
            Color(*C_WALL_D)
            Rectangle(pos=(cx, cy), size=(ts, ts * 0.18))
            Rectangle(pos=(cx, cy + ts * 0.82), size=(ts, ts * 0.18))
        elif ch == ".":
            Color(*C_EARTH)
            Rectangle(pos=(cx, cy), size=(ts, ts))
            Color(*C_EARTH_D)
            h = (cx * 7 + cy * 13) % 3
            Rectangle(pos=(cx + ts * (0.2 + 0.25 * h), cy + ts * 0.45),
                      size=(ts * 0.12, ts * 0.12))
            Rectangle(pos=(cx + ts * 0.55, cy + ts * (0.2 + 0.25 * h)),
                      size=(ts * 0.12, ts * 0.12))
        elif ch == "R":
            Color(*C_ROCK)
            Rectangle(pos=(cx + ts * 0.06, cy + ts * 0.06),
                      size=(ts * 0.88, ts * 0.88))
            Color(*C_ROCK_D)
            Rectangle(pos=(cx + ts * 0.06, cy + ts * 0.06),
                      size=(ts * 0.88, ts * 0.2))
        elif ch == "G":
            Color(*C_GEM)
            PushMatrix()
            Translate(cx + ts / 2.0, cy + ts / 2.0)
            Rotate(angle=45, origin=(0, 0))
            s = ts * 0.62
            Rectangle(pos=(-s / 2.0, -s / 2.0), size=(s, s))
            PopMatrix()
            Color(*C_GEM_D)
            Rectangle(pos=(cx + ts * 0.42, cy + ts * 0.42),
                      size=(ts * 0.16, ts * 0.16))
        elif ch == "E":
            Color(*C_ENEMY)
            Rectangle(pos=(cx + ts * 0.1, cy + ts * 0.1),
                      size=(ts * 0.8, ts * 0.8))
            Color(1, 1, 1)
            Rectangle(pos=(cx + ts * 0.25, cy + ts * 0.55),
                      size=(ts * 0.16, ts * 0.16))
            Rectangle(pos=(cx + ts * 0.59, cy + ts * 0.55),
                      size=(ts * 0.16, ts * 0.16))
            Color(0, 0, 0)
            Rectangle(pos=(cx + ts * 0.29, cy + ts * 0.55),
                      size=(ts * 0.08, ts * 0.16))
            Rectangle(pos=(cx + ts * 0.63, cy + ts * 0.55),
                      size=(ts * 0.08, ts * 0.16))
        elif ch == "X":
            if self.game.exit_open:
                Color(*C_DOOR_OK)
            else:
                Color(*C_DOOR)
            Rectangle(pos=(cx + ts * 0.12, cy), size=(ts * 0.76, ts))
            Color(*C_BG)
            Rectangle(pos=(cx + ts * 0.28, cy + ts * 0.18),
                      size=(ts * 0.44, ts * 0.7))
            if self.game.exit_open:
                Color(1, 1, 0.6, 0.8)
                Rectangle(pos=(cx + ts * 0.42, cy + ts * 0.35),
                          size=(ts * 0.16, ts * 0.16))

    def draw_player(self, cx, cy, ts):
        Color(*C_PLAYER)
        Rectangle(pos=(cx + ts * 0.12, cy + ts * 0.12),
                  size=(ts * 0.76, ts * 0.76))
        Color(0.9, 0.5, 0.05)
        Rectangle(pos=(cx + ts * 0.12, cy + ts * 0.12),
                  size=(ts * 0.76, ts * 0.2))
        Color(1, 1, 1)
        Rectangle(pos=(cx + ts * 0.28, cy + ts * 0.55),
                  size=(ts * 0.16, ts * 0.16))
        Rectangle(pos=(cx + ts * 0.58, cy + ts * 0.55),
                  size=(ts * 0.16, ts * 0.16))
        Color(0, 0, 0)
        Rectangle(pos=(cx + ts * 0.32, cy + ts * 0.55),
                  size=(ts * 0.08, ts * 0.16))
        Rectangle(pos=(cx + ts * 0.62, cy + ts * 0.55),
                  size=(ts * 0.08, ts * 0.16))

# ---------------------------------------------------------------------------
# Приложение
# ---------------------------------------------------------------------------
class KladApp(App):
    def build(self):
        self.title = "КЛАД"
        load_sounds()
        game = Game()

        root = BoxLayout(orientation="vertical")

        hud = Label(markup=True, size_hint=(1, None), height="38dp",
                    font_size="15sp", color=(0.9, 0.9, 0.9),
                    background_color=(0.1, 0.1, 0.18, 1))
        with hud.canvas.before:
            Color(0.1, 0.1, 0.18, 1)
            hud._bg = Rectangle(pos=hud.pos, size=hud.size)
        hud.bind(pos=lambda i, v: setattr(i._bg, "pos", v),
                 size=lambda i, v: setattr(i._bg, "size", v))

        play_area = FloatLayout(size_hint=(1, 1))

        game_widget = GameWidget(game, hud, None, size_hint=(1, 1))
        play_area.add_widget(game_widget)

        overlay = Label(text="", markup=True, font_size="22sp",
                        halign="center", valign="middle",
                        size_hint=(0.8, 0.7),
                        pos_hint={"center_x": 0.5, "center_y": 0.5},
                        color=(1, 1, 0.4))
        play_area.add_widget(overlay)
        game_widget.overlay = overlay

        root.add_widget(hud)
        root.add_widget(play_area)
        root.add_widget(self.build_controls(game))

        # клавиатура (для ПК)
        keymap = {
            273: "up", 274: "down", 276: "left", 275: "right",   # стрелки
            119: "up", 115: "down", 97: "left", 100: "right",    # WASD
        }
        Window.bind(on_key_down=lambda w, k, *a: keymap.get(k) and game.set_dir(keymap[k]))
        Window.bind(on_key_up=lambda w, k, *a: keymap.get(k) and game.clear_dir(keymap[k]))

        return root

    def build_controls(self, game):
        bar = BoxLayout(orientation="horizontal",
                        size_hint=(1, None), height="96dp",
                        padding="6dp", spacing="6dp")

        pad = GridLayout(cols=3, rows=3, size_hint=(None, 1),
                         width="180dp", spacing="3dp")
        pad.add_widget(Label())
        pad.add_widget(self._btn("▲", "up", game))
        pad.add_widget(Label())
        pad.add_widget(self._btn("◀", "left", game))
        pad.add_widget(Label())
        pad.add_widget(self._btn("▶", "right", game))
        pad.add_widget(Label())
        pad.add_widget(self._btn("▼", "down", game))
        pad.add_widget(Label())

        info = Label(text="КОПАЙ • СОБИРАЙ КЛАД\nБЕГИ ОТ КАМНЕЙ И ЖУКОВ",
                     font_size="13sp", color=(0.7, 0.7, 0.8),
                     size_hint=(1, 1), halign="center")

        bar.add_widget(pad)
        bar.add_widget(info)
        return bar

    def _btn(self, sym, d, game):
        b = Button(text=sym, font_size="26sp",
                   background_color=(0.25, 0.25, 0.35, 0.7),
                   background_normal="")
        b.bind(on_press=lambda i: game.set_dir(d))
        b.bind(on_release=lambda i: game.clear_dir(d))
        return b


if __name__ == "__main__":
    KladApp().run()
