# КЛАД — 8-битная аркада для Android (Boulder Dash-like)

Игра в духе Dendy/NES: копайте землю, собирайте самоцветы, избегайте
падающих валунов и жуков. Когда наберёте нужное число самоцветов —
откроется выход. 3 уровня, счёт, таймер, 3 жизни.

Управление: экранный D-pad на телефоне, стрелки / WASD на ПК.

## 1. Запуск на компьютере (проверка)

    pip install kivy
    python main.py

## 2. Сборка APK на своём ПК (Linux)

Установите buildozer (нужны Linux, ~10 ГБ места, python3, pip):

    pip install buildozer
    buildozer -v android debug

Готовый APK появится в `bin/klad-1.0-arm64-v8a-debug.apk` (и armeabi-v7a).
На Windows/macOS удобнее использовать WSL2 с Ubuntu или Docker:

    docker run --rm -v "$PWD":/home/user/hostcwd kivy/buildozer android debug

## 3. Сборка в облаке без установки ничего (GitHub Actions)

1. Создайте репозиторий на GitHub и залейте туда все файлы проекта
   (включая `.github/workflows/build.yml`).
2. Откройте вкладку **Actions** → **Build Klad APK** → **Run workflow**.
3. Через ~20–30 минут в артефактах запуска появится готовый `.apk`
   (скачайте архив `klad-apk`).

## 4. Установка на телефон

Скопируйте APK на телефон, откройте — Android попросит разрешить
установку из неизвестных источников. Подтвердите.

## Структура проекта

    main.py               — код игры (Kivy)
    assets/*.wav          — звуки (8-бит)
    icon.png              — иконка приложения
    buildozer.spec        — конфигурация сборки APK
    .github/workflows/    — автосборка APK в облаке
